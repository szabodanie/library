﻿using librarydb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/books")]
[ApiController]
public class BooksController : ControllerBase
{
    private readonly LibrarydbContext _context;

    public BooksController(LibrarydbContext context)
    {
        _context = context;
    }

  
    [HttpGet("feladat10")]
    public async Task<ActionResult<IEnumerable<Book>>> GetBooks()
    {
        var books = await _context.Books
                                   .Include(b => b.Author)
                                   .Include(b => b.Category)
                                   .ToListAsync();

        if (books == null)
        {
            return BadRequest("Hiba történt a könyvek lekérésekor.");
        }

        return Ok(books);
    }

   
    [HttpPost("feladat13")]
    public async Task<ActionResult> PostBook([FromQuery] string uid, [FromBody] Book book)
    {
        const string allowedUserId = "FKB3F4FEA09CE43C";
        if (uid != allowedUserId)
        {
            return Unauthorized("Nincs jogosultsága új könyv felvételéhez!");
        }

        _context.Books.Add(book);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetBooks", new { id = book.BookId }, book);
    }
}
