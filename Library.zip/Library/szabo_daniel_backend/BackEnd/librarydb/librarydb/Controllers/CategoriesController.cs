﻿using librarydb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/categories")]
[ApiController]
public class CategoriesController : ControllerBase
{
    private readonly LibrarydbContext _context;

    public CategoriesController(LibrarydbContext context)
    {
        _context = context;
    }

  
    [HttpGet("feladat11")]
    public async Task<ActionResult> GetCategories()
    {
        var categories = await _context.Categories
                                       .Include(c => c.Books)
                                       .ThenInclude(b => b.Author)
                                       .ToListAsync();

        if (categories == null)
        {
            return BadRequest("Error fetching categories.");
        }

        return Ok(categories);
    }
}
