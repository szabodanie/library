﻿using librarydb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/authors")]
[ApiController]
public class AuthorsController : ControllerBase
{
    private readonly LibrarydbContext _context;

    public AuthorsController(LibrarydbContext context)
    {
        _context = context;
    }

  
    [HttpGet("feladat9/{authorName}")]
    public async Task<ActionResult> GetAuthorBooks(string authorName)
    {
        var author = await _context.Authors
                                   .Include(a => a.Books)
                                   .ThenInclude(b => b.Category)
                                   .FirstOrDefaultAsync(a => a.Name == authorName);

        if (author == null)
        {
            return NotFound("Author nem található.");
        }

        return Ok(author);
    }
}
